    function mouseonwood() {
        document.getElementById("woodbox").style.opacity = "1";
    }

    function mouseoffwood() {
        document.getElementById("woodbox").style.opacity = "0";
    }




    function mouseonmetal() {
        document.getElementById("metalbox").style.opacity = "1";
    }

    function mouseoffmetal() {
        document.getElementById("metalbox").style.opacity = "0";
    }



    function mouseonscan() {
        document.getElementById("scanbox").style.opacity = "1";
    }

    function mouseoffscan() {
        document.getElementById("scanbox").style.opacity = "0";
    }



    function mouseonprint() {
        document.getElementById("printbox").style.opacity = "1";
    }

    function mouseoffprint() {
        document.getElementById("printbox").style.opacity = "0";
    }



    function mouseoncnc() {
        document.getElementById("cncbox").style.opacity = "1";
    }

    function mouseoffcnc() {
        document.getElementById("cncbox").style.opacity = "0";
    }



    function mouseonlaser() {
        document.getElementById("laserbox").style.opacity = "1";
    }

    function mouseofflaser() {
        document.getElementById("laserbox").style.opacity = "0";
    }




    function mouseonrobot() {
        document.getElementById("robotbox").style.opacity = "1";
    }

    function mouseoffrobot() {
        document.getElementById("robotbox").style.opacity = "0";
    }